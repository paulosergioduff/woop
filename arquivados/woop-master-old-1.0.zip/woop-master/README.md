# woop
Woop é a sigla em inglês para "Writer Object-oriented programming" (Escritor de programação orientada a objetos). Uma classe para facilitar a escritas e modificação de arquivos através do PHP.

## ATENÇÃO!
Até a edição final deste arquivo readme-me, não utilize a classe woop fora de ambiente local. O motivo é cautela para evitar má intenções de terceiros. Alguém mal intencionado poderia manipular o formulário para alterar o arquivo .htaccess e ter acesso ao servidor. Após a edição deste arquivo Read-me, esse problema será corrigido
